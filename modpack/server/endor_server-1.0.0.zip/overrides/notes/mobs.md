## Mobs/NPC Mods

- **goblin-traders**
  Optional to cross-list — Adds tiny trader goblins that appear randomly and offer special item trades.
