## Visual/Atmosphere Mods

- **antique-atlas**  
  Adds a gorgeous hand-drawn-style map (like a fantasy atlas). Great for immersion and exploration flavor.

  - **dependencies:**
    - surveyor

- **jade**  
  Shows tooltips over blocks and entities with extra info (like what mod it's from or what's inside a chest). Useful but also slightly aesthetic.

- **biomes-o-plenty**
  Better/bigger biomes
  **dependencies:**
  - TerraBlender
  - GlitchCore
