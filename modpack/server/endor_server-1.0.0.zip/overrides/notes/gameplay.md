## Gameplay/Mechanics Mods

- **corpse**  
  When a player dies, a corpse is left behind with all their items safely stored — great for immersion and item recovery.

- **waystones**  
  Adds teleportation via craftable stone waypoints. Maintains exploration while offering magical fast travel.

- **netherportalfix**  
  Fixes vanilla's often broken Nether portal linking logic — ensures consistent two-way travel.
